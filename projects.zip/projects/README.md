# Celebal Technology Data Science Project

## Project Overview
This project uses a dataset from the 20 Newsgroups dataset and applies topic modeling and clustering techniques to analyze and group the documents. The primary techniques used are:

*   **TF-IDF (Term Frequency-Inverse Document Frequency)**: Used to convert the text data into a numerical format suitable for machine learning models.
*   **Latent Dirichlet Allocation (LDA)**: A topic modeling technique used to discover the underlying topics within the documents.
*   **K-means Clustering**:  A clustering algorithm used to group the documents based on the topics identified by LDA.

## Project Structure
*   `data_science_project_celebal_technology.ipynb`:  Jupyter Notebook containing the code for data loading, preprocessing, topic modeling, clustering, and visualization.
*   `document_clusters.csv`: CSV file containing the document IDs and their cluster assignments.
*   (potentially other files created during the process if any)

## Technologies Used
*   Python
*   Libraries:
    *   `os`
    *   `tarfile`
    *   `pandas`
    *   `sklearn` (specifically `TfidfVectorizer`, `LatentDirichletAllocation`, `KMeans`, and `PCA`)
    *   `nltk` (specifically `stopwords`, `WordNetLemmatizer`, and `word_tokenize`)
    *   `re`
    *   `matplotlib`

## Data
*   **Dataset**: 20 Newsgroups dataset.  The notebook appears to load data from the `/content/20_newsgroups.tar.gz` archive.
*   **Category**: misc.forsale category is used for this project.

## Steps

1.  **Install Required Libraries**: Ensure that the necessary Python libraries are installed before running the notebook.
2.  **Data Loading and Extraction**:
    *   The data is loaded from the compressed file.
    *   The `misc.forsale` category is extracted.
3.  **Data Preprocessing**:
    *   Stop words are removed.
    *   Text is lemmatized.
    *   Non-alphabetic characters are removed, and text is converted to lowercase.
    *   Text is tokenized.
4.  **TF-IDF Vectorization**:
    *   TF-IDF is applied to convert text into numerical data.
5.  **Topic Modeling (LDA)**:
    *   LDA is used to identify topics within the documents.
    *   Topics and keywords are displayed.
6.  **Clustering (K-means)**:
    *   K-means is applied to cluster the documents.
7.  **Results**:
    *   The clustering results are attached to the documents and saved to a CSV file.
    *   The clusters are visualized using bar charts and scatter plots.

## Instructions to Run
1.  **Environment Setup**: Make sure you have Python and the libraries mentioned above installed.  A virtual environment is recommended.
2.  **Download Dataset**: Download the  `20_newsgroups.tar.gz`  file and place it in the appropriate location or adjust the  `data_path`  variable in the notebook. The current notebook uses data present at `/content/20_newsgroups.tar.gz`
3.  **Run the Notebook**: Open and execute the  `data_science_project_celebal_technology.ipynb`  file in a Jupyter Notebook environment.

## Key Files

*   `data_science_project_celebal_technology.ipynb`: The main notebook with code, results, and visualizations.
*   `document_clusters.csv`:  CSV file containing the clustering results.

## Potential Improvements
*   Explore other clustering algorithms.
*   Evaluate the quality of topics.
*   Use different text preprocessing steps.
*   Try other datasets.

## Author
*   Supriya Kumari 