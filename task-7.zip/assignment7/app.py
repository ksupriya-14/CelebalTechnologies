import streamlit as st
import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report

# Set page config
st.set_page_config(
    page_title="Iris Flower Classifier",
    page_icon="🌸",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load model and data
@st.cache_resource
def load_model():
    return joblib.load('model/iris_model.pkl')

@st.cache_data
def load_data():
    return pd.read_csv('data/iris.csv')

model = load_model()
sample_data = load_data()

# Sidebar
st.sidebar.title("About")
st.sidebar.info(
    """
    This app predicts the species of Iris flowers based on their:
    - Sepal length (cm)
    - Sepal width (cm)
    - Petal length (cm)
    - Petal width (cm)
    """
)

# Main content
st.title("🌸 Iris Flower Classification")
st.markdown("""
This machine learning app predicts the species of Iris flowers using a Random Forest classifier.
""")

# Tabs
tab1, tab2, tab3 = st.tabs(["Predict", "Sample Data", "Model Performance"])

with tab1:
    st.header("Make a Prediction")
    
    # Input form
    with st.form("prediction_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            sepal_length = st.slider("Sepal Length (cm)", 4.0, 8.0, 5.8)
            sepal_width = st.slider("Sepal Width (cm)", 2.0, 4.5, 3.1)
        
        with col2:
            petal_length = st.slider("Petal Length (cm)", 1.0, 7.0, 3.8)
            petal_width = st.slider("Petal Width (cm)", 0.1, 2.5, 1.2)
        
        submitted = st.form_submit_button("Predict")
    
    if submitted:
        # Prepare input data
        input_data = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
        
        # Make prediction
        prediction = model.predict(input_data)
        probabilities = model.predict_proba(input_data)[0]
        
        # Map prediction to species name
        species_map = {0: "setosa", 1: "versicolor", 2: "virginica"}
        predicted_species = species_map[prediction[0]]
        
        # Display results
        st.subheader("Prediction Result")
        st.success(f"The predicted species is **{predicted_species}**")
        
        # Show probabilities
        st.subheader("Prediction Probabilities")
        prob_df = pd.DataFrame({
            "Species": list(species_map.values()),
            "Probability": probabilities
        })
        
        fig, ax = plt.subplots()
        sns.barplot(data=prob_df, x="Species", y="Probability", palette="viridis", ax=ax)
        ax.set_ylim(0, 1)
        ax.set_title("Probability Distribution")
        st.pyplot(fig)

with tab2:
    st.header("Sample Data")
    st.dataframe(sample_data, use_container_width=True)
    
    # Show feature distributions
    st.subheader("Feature Distributions")
    feature = st.selectbox("Select a feature to visualize", sample_data.columns)
    
    fig, ax = plt.subplots()
    sns.histplot(sample_data[feature], kde=True, ax=ax)
    ax.set_title(f"Distribution of {feature}")
    st.pyplot(fig)

with tab3:
    st.header("Model Performance")
    
    # Load full dataset for evaluation
    from sklearn.datasets import load_iris
    iris = load_iris()
    X = iris.data
    y = iris.target
    
    # Make predictions
    y_pred = model.predict(X)
    
    # Confusion matrix
    st.subheader("Confusion Matrix")
    cm = confusion_matrix(y, y_pred)
    
    fig, ax = plt.subplots()
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=iris.target_names, 
                yticklabels=iris.target_names,
                ax=ax)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title("Confusion Matrix")
    st.pyplot(fig)
    
    # Classification report
    st.subheader("Classification Report")
    report = classification_report(y, y_pred, target_names=iris.target_names, output_dict=True)
    report_df = pd.DataFrame(report).transpose()
    st.dataframe(report_df, use_container_width=True)
    
    # Feature importance
    st.subheader("Feature Importance")
    importance = model.feature_importances_
    features = iris.feature_names
    
    fig, ax = plt.subplots()
    sns.barplot(x=importance, y=features, palette="rocket", ax=ax)
    ax.set_title("Feature Importance")
    st.pyplot(fig)