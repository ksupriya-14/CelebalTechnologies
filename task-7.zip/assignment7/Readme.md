# Iris Flower Classification with Streamlit

![Streamlit App](https://img.shields.io/badge/Streamlit-FF4B4B?style=for-the-badge&logo=Streamlit&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Scikit-learn](https://img.shields.io/badge/scikit--learn-%23F7931E.svg?style=for-the-badge&logo=scikit-learn&logoColor=white)

A web application for classifying Iris flower species using machine learning, built with Streamlit.

## 🌟 Features

- Interactive prediction interface with sliders for input
- Real-time species classification
- Visualizations of prediction probabilities
- Model performance analysis (confusion matrix, classification report)
- Sample data exploration
- Responsive and user-friendly design

## 🧠 Machine Learning Details

Model: Random Forest Classifier

Dataset: Iris flowers dataset (scikit-learn)

Features:

- Sepal length (cm)
- Sepal width (cm)
- Petal length (cm)
- Petal width (cm)

Target Classes:

- 0: setosa
- 1: versicolor
- 2: virginica


## 🌐 Deployment

You can deploy this app to:

1. **Streamlit Sharing** (recommended for quick deployment)
2. **Heroku**
3. **AWS/Azure/GCP**
4. **Docker container**

### Streamlit Sharing Deployment

1. Push your code to GitHub
2. Go to [Streamlit Sharing](https://share.streamlit.io/)
3. Connect your GitHub account
4. Select repository and main file (`app.py`)
5. Click "Deploy"
